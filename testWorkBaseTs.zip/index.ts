import app from './src/app.js'
import envConfig from './src/Configs/envConfig.js'


app.listen(envConfig.Port, ()=>{
    console.log(`Server is listening on port: ${envConfig.Port}\nServer in ${envConfig.Status}\nEverything is allright !! 😎`)
})