import {describe, it, expect }from 'vitest'
import envConfig from './envConfig.ts'

describe('Environment variables', () => { 
    it('should return the correct environment status and database variable', () => { 
         const formatEnvInfo =
      `Server running in: ${envConfig.Status}\n` +
      `Testing database: ${envConfig.DatabaseUrl}`;
    expect(formatEnvInfo).toBe(
      "Server running in: test\n" + "Testing database: mongodb://127.0.0.1:27017/herethenameofdb"
    );
    })
})