export interface IRepositoryResponse<T> {
  results: T
}
export interface IOrder<TDTO> {
  field: keyof TDTO
  direction: 1 | -1
}
export interface IPaginatedOptions<TDTO> {
  query?: Partial<Record<keyof TDTO, unknown>>
  page?: number
  limit?: number
  order?: IOrder<TDTO>
}
export interface IPaginatedResults<TDTO> {
  info: { total: number, page: number, limit: number, totalPages: number }
  data: TDTO[]
}
export interface IBaseRepository<TDTO, TCreate, TUpdate> {
  getAll: (field?: unknown, whereField?: keyof TDTO | string) => Promise<TDTO[]>
  getById: (id: string | number) => Promise<IRepositoryResponse<TDTO>>
  getByField: (field: unknown, whereField: keyof TDTO | string) => Promise<IRepositoryResponse<TDTO>>
  getWithPages: (options?: IPaginatedOptions<TDTO>) => Promise<IPaginatedResults<TDTO>>
  create: (data: TCreate) => Promise<IRepositoryResponse<TDTO>>
  update: (id: string | number, data: TUpdate) => Promise<IRepositoryResponse<TDTO>>
  delete: (id: string | number) => Promise<IRepositoryResponse<string>>
}
export interface IExternalImageDeleteService<T> {
  deleteImage: (imageInfo: T) => Promise<boolean>
}
export const mockImageDeleteService: IExternalImageDeleteService<any> = {
  deleteImage: async (_imageInfo: any) => await Promise.resolve(true)
}
